

<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
            <h1 class="text-xl font-semibold tracking-tight">Servicios</h1>
            <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Servicios, duración y precios.</p>
        </div>
        <button id="openServiceModal" type="button" class="inline-flex w-full items-center justify-center rounded-lg bg-slate-900 px-3 py-2 text-sm font-semibold text-white hover:bg-slate-800 sm:w-auto">
            Nuevo servicio
        </button>
    </div>

    <div class="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900/40">
        <form method="get" action="<?php echo e(route('services.index', [], false)); ?>" class="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end">
            <div class="w-full sm:flex-1 sm:min-w-[16rem]">
                <label for="q" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">Buscar</label>
                <input id="q" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" class="mt-1 w-full rounded-md border border-slate-300 bg-white focus:border-slate-900 focus:ring-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-slate-200 dark:focus:ring-slate-200" placeholder="Entidad o nombre del servicio" />
            </div>

            <div class="w-full sm:w-56">
                <label for="is_active" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">Activo</label>
                <select id="is_active" name="is_active" data-placeholder-select class="mt-1 w-full rounded-md border border-slate-300 bg-white text-slate-900 focus:border-slate-900 focus:ring-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-slate-200 dark:focus:ring-slate-200">
                    <option value="" disabled hidden <?php if(($filters['is_active'] ?? null) === null): echo 'selected'; endif; ?>>Seleccionar una opción</option>
                    <option value="1" <?php if(($filters['is_active'] ?? null) === true): echo 'selected'; endif; ?>>Sí</option>
                    <option value="0" <?php if(($filters['is_active'] ?? null) === false): echo 'selected'; endif; ?>>No</option>
                </select>
            </div>

            <div class="flex w-full items-center gap-2 sm:w-auto sm:ml-auto">
                <button class="inline-flex items-center rounded-lg bg-slate-900 px-3 py-2 text-sm font-semibold text-white hover:bg-slate-800">Filtrar</button>
                <a href="<?php echo e(route('services.index', [], false)); ?>" class="text-sm font-semibold text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-slate-100">Limpiar</a>
            </div>
        </form>
    </div>

    <div class="mt-6 overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
        <div class="overflow-x-auto">
            <table class="table-grid min-w-full divide-y divide-slate-200 dark:divide-slate-800">
                <thead class="bg-slate-900 dark:bg-slate-900">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-white dark:text-slate-200 whitespace-nowrap">Nombre</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-white dark:text-slate-200 whitespace-nowrap">Duración</th>
                        <th class="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-white dark:text-slate-200 whitespace-nowrap">Precio</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-white dark:text-slate-200 whitespace-nowrap">Estado</th>
                        <th class="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-white dark:text-slate-200 whitespace-nowrap">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-900/40">
                            <td class="px-4 py-3 text-sm font-semibold text-slate-900 dark:text-slate-100">
                                <?php echo e($service->name); ?>

                            </td>
                            <td class="px-4 py-3 text-sm text-slate-700 dark:text-slate-200">
                                <?php echo e($service->duration_minutes); ?> min
                            </td>
                            <td class="px-4 py-3 text-center text-sm font-semibold text-slate-900 dark:text-slate-100 whitespace-nowrap tabular-nums">
                                $ <?php echo e(number_format(($service->price_cents ?? 0) / 100, 2, ',', '.')); ?>

                            </td>
                            <td class="px-4 py-3">
                                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                    'inline-flex items-center whitespace-nowrap rounded-full px-2 py-1 text-xs font-semibold',
                                    'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-200' => $service->is_active,
                                    'bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300' => ! $service->is_active,
                                ]); ?>">
                                    <?php echo e($service->is_active ? 'Activo' : 'Inactivo'); ?>

                                </span>
                            </td>
                            <td class="px-4 py-3 text-right">
                                <button
                                    type="button"
                                    data-service-edit
                                    data-service-id="<?php echo e($service->id); ?>"
                                    data-service-name="<?php echo e($service->name); ?>"
                                    data-service-duration-minutes="<?php echo e($service->duration_minutes); ?>"
                                    data-service-price-cents="<?php echo e($service->price_cents ?? 0); ?>"
                                    data-service-is-active="<?php echo e($service->is_active ? '1' : '0'); ?>"
                                    data-service-update-url="<?php echo e(route('services.update', ['service' => $service->id], false)); ?>"
                                    class="inline-flex items-center rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-900"
                                >
                                    Editar
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-8 text-center text-sm text-slate-500 dark:text-slate-400">No hay servicios para mostrar.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($services->hasPages()): ?>
            <div class="px-4 py-3">
                <?php echo e($services->links()); ?>

            </div>
        <?php endif; ?>
    </div>

    <div
        id="serviceModal"
        data-open-on-load="<?php echo e(($errors->any() && old('_form') === 'service') ? '1' : '0'); ?>"
        class="fixed inset-0 z-50 hidden"
        aria-hidden="true"
    >
        <div class="absolute inset-0 bg-slate-900/50" data-modal-overlay></div>

        <div class="relative mx-auto flex min-h-full max-w-xl items-start justify-center p-4 sm:items-center">
            <div class="w-full max-h-[calc(100vh-2rem)] overflow-y-auto rounded-2xl bg-white shadow-xl dark:bg-slate-950">
                <div class="flex items-start justify-between border-b border-slate-200 px-5 py-4 dark:border-slate-800">
                    <div>
                        <div id="serviceModalTitle" class="text-lg font-semibold text-slate-900 dark:text-slate-100">
                            <?php echo e((old('_form') === 'service' && old('service_id')) ? 'Editar servicio' : 'Nuevo servicio'); ?>

                        </div>
                        <div id="serviceModalSubtitle" class="mt-1 text-sm text-slate-500 dark:text-slate-400">Nombre, duración y precio.</div>
                    </div>
                    
                </div>

                <form
                    id="serviceForm"
                    method="post"
                    action="<?php echo e((old('_form') === 'service' && old('service_id')) ? route('services.update', ['service' => old('service_id')], false) : route('services.store', [], false)); ?>"
                    data-create-url="<?php echo e(route('services.store', [], false)); ?>"
                    class="px-5 py-4"
                >
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_form" value="service" />
                    <input type="hidden" id="serviceEditId" name="service_id" value="<?php echo e(old('service_id')); ?>" />

                    <?php if(old('_form') === 'service' && old('service_id')): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>

                    <?php if($errors->any() && old('_form') === 'service'): ?>
                        <div class="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">
                            <div class="font-semibold">Revisá estos campos:</div>
                            <ul class="mt-1 list-disc pl-5">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div class="sm:col-span-2">
                            <label for="name" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">Nombre</label>
                            <input id="name" name="name" value="<?php echo e(old('name')); ?>" required class="mt-1 w-full rounded-lg border-slate-300 bg-white text-slate-900 focus:border-slate-900 focus:ring-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-slate-200 dark:focus:ring-slate-200" />
                        </div>

                        <div>
                            <label for="duration_minutes" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">Duración (min)</label>
                            <input id="duration_minutes" name="duration_minutes" type="number" min="1" step="1" value="<?php echo e(old('duration_minutes')); ?>" required class="mt-1 w-full rounded-lg border-slate-300 bg-white text-slate-900 focus:border-slate-900 focus:ring-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-slate-200 dark:focus:ring-slate-200" />
                        </div>

                        <div>
                            <label for="price" class="block text-sm font-semibold text-slate-700 dark:text-slate-200">Precio</label>
                            <input id="price" name="price" type="number" min="0" step="0.01" value="<?php echo e(old('price')); ?>" required class="mt-1 w-full rounded-lg border-slate-300 bg-white text-slate-900 focus:border-slate-900 focus:ring-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-slate-200 dark:focus:ring-slate-200" />
                        </div>

                        <label class="sm:col-span-2 inline-flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200">
                            <input type="hidden" name="is_active_new" value="0" />
                            <input type="checkbox" name="is_active_new" value="1" <?php if(old('is_active_new', '1') == '1'): echo 'checked'; endif; ?> class="rounded border-slate-300 text-slate-900 focus:ring-slate-900 dark:border-slate-700 dark:text-slate-100 dark:focus:ring-slate-200" />
                            Activo
                        </label>
                    </div>

                    <div class="mt-6 flex items-center justify-end gap-2 border-t border-slate-200 pt-4 dark:border-slate-800">
                        <button type="button" class="inline-flex items-center rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-900" data-modal-close>
                            Cancelar
                        </button>
                        <button type="submit" class="inline-flex items-center rounded-lg bg-slate-900 px-3 py-2 text-sm font-semibold text-white hover:bg-slate-800">
                            Aceptar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lautaro\Desktop\SpaProgram\backend\resources\views/pages/services/index.blade.php ENDPATH**/ ?>