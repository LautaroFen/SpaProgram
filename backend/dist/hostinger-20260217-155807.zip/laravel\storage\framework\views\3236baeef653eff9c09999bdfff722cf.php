

<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h1 class="text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">Turnos de la semana</h1>
            <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">
                <?php echo e($weekStart->isoFormat('D MMM')); ?> – <?php echo e($weekEnd->isoFormat('D MMM YYYY')); ?>

            </p>
        </div>

        <div class="flex items-center gap-2">
            <a
                href="<?php echo e(route('dashboard', ['week' => $weekStart->subWeek()->toDateString()], false)); ?>"
                class="inline-flex items-center rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-900"
            >
                Semana anterior
            </a>
            <a
                href="<?php echo e(route('dashboard', ['week' => $weekStart->addWeek()->toDateString()], false)); ?>"
                class="inline-flex items-center rounded-lg bg-slate-900 px-3 py-2 text-sm font-semibold text-white hover:bg-slate-800"
            >
                Semana siguiente
            </a>
        </div>
    </div>

    <div class="mt-6">
        <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $dateKey = $day->toDateString();
                    $items = $appointmentsByDay->get($dateKey, collect());
                ?>

                <div class="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900/40">
                    <div class="border-b border-slate-200 px-3 py-2 dark:border-slate-800">
                        <div class="text-sm font-semibold text-slate-900 dark:text-slate-100"><?php echo e($day->isoFormat('dddd')); ?></div>
                        <div class="text-xs text-slate-500 dark:text-slate-400"><?php echo e($day->isoFormat('D MMM')); ?></div>
                    </div>

                    <div class="p-3 space-y-2 min-h-[220px]">
                        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="rounded-lg border border-slate-200 p-2 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-950/30 dark:hover:bg-slate-950/50">
                                <div class="flex items-center justify-between gap-2">
                                    <div class="text-xs font-semibold text-slate-700 dark:text-slate-200">
                                        <?php echo e($appt->start_at->format('H:i')); ?> – <?php echo e($appt->end_at->format('H:i')); ?>

                                    </div>
                                    <?php
                                        $statusLabel = [
                                            'scheduled' => 'Programado',
                                            'paid' => 'Pagado',
                                            'cancelled' => 'Cancelado',
                                            'no_show' => 'No asistió',
                                        ][$appt->status] ?? '—';

                                        $statusClass = match ($appt->status) {
                                            'paid' => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300',
                                            'scheduled' => 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300',
                                            default => 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200',
                                        };
                                    ?>
                                    <span class="text-[11px] rounded-full px-2 py-0.5 <?php echo e($statusClass); ?>">
                                        <?php echo e($statusLabel); ?>

                                    </span>
                                </div>
                                <div class="mt-1 text-sm font-semibold text-slate-900 dark:text-slate-100">
                                    <?php echo e($appt->client?->full_name ?? 'Cliente'); ?>

                                </div>
                                <div class="text-xs text-slate-500 dark:text-slate-400">
                                    <?php echo e($appt->service?->name ?? 'Servicio'); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-sm text-slate-400">Sin turnos</div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lautaro\Desktop\SpaProgram\backend\resources\views/pages/dashboard/index.blade.php ENDPATH**/ ?>