﻿<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));






 = __DIR__.'/../../laravel';

// Determine if the application is in maintenance mode...
if (file_exists(
     = .'/storage/framework/maintenance.php'
)) {
    require ;
}

// Register the Composer autoloader...
require .'/vendor/autoload.php';

// Bootstrap Laravel and handle the request...
/** @var Application  */
 = require_once .'/bootstrap/app.php';

->handleRequest(Request::capture());
